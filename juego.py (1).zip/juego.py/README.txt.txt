INSTRUCCIONES PARA JUGAR

1. Instala Python 3 si no lo tienes: https://www.python.org/downloads/
2. Abre la terminal/comando y escribe: pip install pygame
3. Ejecuta el archivo juego.py (doble clic, o desde la terminal: python juego.py)
4. ¡Disfruta el juego!